import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Register = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleRegister = (e) => {
    e.preventDefault();
    if (password.length < 8 (password)) {
      setMessage('Password has to be at least 8 characters');
      return;
    }

    localStorage.setItem('username', username);
    localStorage.setItem('password', password);
    setMessage('Successful registration');
    setTimeout(() => navigate('/'), 1500);
  };

  return (
    <div>
      <h2>Register your account</h2>
      <form onSubmit={handleRegister}>
        <input placeholder="Your username" value={username} onChange={(e) => setUsername(e.target.value)} required />
        <input type="password" placeholder="Your password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        <button type="submit">Register account</button>
      </form>
      <p>{message}</p>
    </div>
  );
};

export default Register;
